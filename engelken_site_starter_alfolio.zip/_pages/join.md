---
layout: page
title: Work with me
permalink: /join/
---

I'm looking for self-driven, quantitatively strong students and postdocs who like theory + code and get things done. If you're excited about **learning dynamics**, **chaos**, **spiking networks**, or **neural manifolds**, reach out.

**How to get in touch**  
Email me at **re2365@columbia.edu** with:
- your CV,  
- a brief intro (2–3 sentences), and  
- 1–2 short paragraphs on what you'd like to build here and why.

Undergraduates are welcome.