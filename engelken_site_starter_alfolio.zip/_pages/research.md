---
layout: page
title: Research
permalink: /research/
---

I study how coordinated interactions of neurons give rise to complex population dynamics and computation in biological and artificial neural networks. Using tools from dynamical systems (Lyapunov spectra, covariant vectors, dynamic mean-field theory), I connect single-neuron biophysics to network-level behavior and learning.

## Areas of interest
**Learning Dynamics.** Theory for how activities, synapses, and representations evolve; links between stability and temporal credit assignment; geometry of error signals and task complexity.  

**Chaos & Stability.** Full Lyapunov spectra in RNNs; *sparse chaos* in spiking circuits; controllability and entropy rates; taming/using chaos for computation.  

**Spiking Networks & Efficient Algorithms.** Event-based simulation/training of large SNNs (*SparseProp*); million-neuron exact simulations on CPU; scaling laws; neuromorphic relevance.  

**Neural Manifolds & Replay.** Low-dimensional structure in hippocampal population activity; manifold consistency across trials/days; sequential events during ITIs.