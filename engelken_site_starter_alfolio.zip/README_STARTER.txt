# Starter files for Rainer Engelken — al-folio

These are drop-in pages and a bibliography that work with the **al-folio** theme without touching the theme's own `_config.yml`.

## How to use

1. Copy all files/folders in this archive into the root of your repository `rainer-engelken.github.io` (created from **alshedivat/al-folio**).
2. Put your headshot at `assets/img/avatar.png` (optional for now).
3. Put your CV PDF at `assets/pdf/Engelken_CV.pdf`.
4. Run locally:
   ```bash
   bundle exec jekyll serve --livereload
   ```
5. Visit http://127.0.0.1:4000 and click through the pages.

### Where to edit later

- **Home intro**: `index.md`
- **Research page**: `_pages/research.md`
- **Publications**: `_pages/publications.md` and `_bibliography/papers.bib`
- **Teaching**: `_pages/teaching.md`
- **Work with me**: `_pages/join.md`
- **CV link**: `_pages/cv.md` + `assets/pdf/Engelken_CV.pdf`
- **Social icons in header/footer**: edit `_data/socials.yml` in your repo (already provided by the theme). Add Scholar/GitHub/X/Bluesky there.
- **Site title/description** (optional): edit the existing `_config.yml` (keep `url` and `baseurl` per al-folio docs).

If you prefer the "About" profile layout on the home page, you can switch `index.md` to use `layout: about` later and fill your details in `_config.yml` / `_data/socials.yml`.