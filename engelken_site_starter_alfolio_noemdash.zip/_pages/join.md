---
layout: page
title: Work with me
permalink: /join/
---

I am looking for self driven, quantitatively strong students and postdocs who like theory and code and get things done. If you are excited about learning dynamics, chaos, spiking networks, or neural manifolds, reach out.

**How to get in touch**
Email me at **re2365@columbia.edu** and include your CV, a short introduction, and one or two short paragraphs on what you would like to build here and why.

Undergraduates are welcome.